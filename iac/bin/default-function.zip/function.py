import json

def handler(event, context):
  print(f"Received event: {json.dumps(event, indent=2)}")
  dummy_response = {
    "statusCode": 200,
    "body": "Hello from Lambda!"
  }
  print(f"Returning response: {json.dumps(dummy_response, indent=2)}")
  return dummy_response